"""Run the original 21-by-21 proof package directly from this ZIP."""
import hashlib
import io
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile


def main():
    source_digest = "810472882b85e708860067cb1e0521287e5a80686c5ee348ccd4fa244fa0e4c5"
    with zipfile.ZipFile(sys.argv[0]) as launcher:
        payload = launcher.read("Queens21_Reproducibility.zip")
    if hashlib.sha256(payload).hexdigest() != source_digest:
        sys.exit("The proof archive failed its SHA-256 check. Download a fresh copy.")

    with zipfile.ZipFile(io.BytesIO(payload)) as archive, tempfile.TemporaryDirectory(prefix="queens21-") as folder:
        expected = {f"queens21/results/parts/{i * 512:06d}.json" for i in range(1025)}
        actual = {name for name in archive.namelist()
                  if name.startswith("queens21/results/parts/") and name.endswith(".json")}
        if actual != expected:
            sys.exit("The proof archive failed its list of required cases.")
        archive.extractall(folder)
        print("Package verified. All 1,025 case files are present.", flush=True)
        result = subprocess.run([sys.executable, "-u", "verify.py", *sys.argv[1:]],
                                cwd=Path(folder) / "queens21")
        return result.returncode


if __name__ == "__main__":
    sys.exit(main())
